/*
 <codex>
 <abstract>
 Main body for n-body simulation.
 </abstract>
 </codex>
 */

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    @autoreleasepool
    {
        return NSApplicationMain(argc, (const char **)argv);
    }
} // main
