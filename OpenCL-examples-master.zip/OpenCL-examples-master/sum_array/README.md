OpenCL Vector Addition
=====================

This sample shows an OpenCL vector addition code. Consider this a OpenCL ‘Hello World’. Error handling is not included so that the structure of the code is more digestible. 

Downloaded from the [OLCF](https://www.olcf.ornl.gov/tutorials/opencl-vector-addition/). Please visit their [GitHub page](https://github.com/olcf/vector_addition_tutorials). Please direct any questions or comments to `help@nccs.gov`.

