Simple example of OpenCL code that adds a series of numbers together. 

Code taken from ["A Gentle Introduction to OpenCL" by Matthew Scarpino](http://www.drdobbs.com/parallel/a-gentle-introduction-to-opencl/231002854). 

